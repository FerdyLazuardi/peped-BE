<?php
$string['pluginname']            = 'AI Chatbot';
$string['chatbot:addinstance']   = 'Add AI Chatbot block';
$string['chatbot:myaddinstance'] = 'Add AI Chatbot block to my page';
