<?php
function xmldb_block_chatbot_install() {
    global $DB;

    if ($DB->record_exists('block_instances', ['blockname' => 'chatbot'])) {
        return true;
    }

    $syscontext = context_system::instance();

    $DB->insert_record('block_instances', (object)[
        'blockname'         => 'chatbot',
        'parentcontextid'   => $syscontext->id,
        'showinsubcontexts' => 1,
        'requiredbytheme'   => 0,
        'pagetypepattern'   => '*',
        'subpagepattern'    => null,
        'defaultregion'     => 'side-pre',
        'defaultweight'     => -10,
        'timecreated'       => time(),
        'timemodified'      => time(),
        'configdata'        => ''
    ]);

    return true;
}
