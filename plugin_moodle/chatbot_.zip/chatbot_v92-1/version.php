<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'block_chatbot';
$plugin->version   = 2026010100;
$plugin->requires  = 2022041900;
